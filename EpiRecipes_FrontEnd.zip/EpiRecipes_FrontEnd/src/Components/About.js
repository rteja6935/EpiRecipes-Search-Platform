import React from 'react';
import '../App.css'
const About = () => {
  return(
    <div className='about-container'>
         <h2>About Epi Recipes</h2>
        <p className='para'>
        Welcome to EpiRecipes, the ultimate hub for food enthusiasts! Our platform curates an extensive collection of mouth-watering recipes sourced from a variety of cuisines, each tailored for food lovers looking for inspiration in their culinary adventures. Whether you’re a seasoned chef or an enthusiastic home cook, EpiRecipes has something to satisfy every craving.

Our recipes cover a broad spectrum, from simple everyday meals to gourmet dishes, focusing on quality ingredients, easy-to-follow instructions, and diverse flavors. We categorize our recipes by cuisine, dietary preferences, cooking time, and nutritional value, so you can easily find the perfect meal for any occasion. Whether you’re searching for low-calorie dishes, gluten-free options, or indulgent desserts, EpiRecipes brings the world of flavors right to your kitchen.
        </p>
        <ul>Popular Categories Include:</ul>
        <ul>
        <li>Quick & Easy: Perfect for busy weeknights with minimal prep time.</li>
        <li>Healthy & Nutritious: Featuring low-calorie, low-carb, and balanced meal options.</li>
        <li>Global Cuisines: Explore recipes from all over the world, including Italian, Indian, Mexican, and more.</li>
        <li>Desserts & Baking: For those with a sweet tooth, indulge in cakes, cookies, and pastries.</li>
        <li>Special Diets: Find vegan, vegetarian, gluten-free, and keto recipes designed to fit your lifestyle.</li>
        <li>At EpiRecipes, our goal is to make cooking both fun and accessible, turning every meal into a memorable experience. Join us on this delicious journey and let’s explore the world, one recipe at a time!</li>
        </ul>
 
  </div>
  );
};

export default About;
