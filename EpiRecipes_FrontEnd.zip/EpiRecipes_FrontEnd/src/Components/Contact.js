import React from 'react';

const Contact = () => {
  return(
    <div className='about-container'>
        <h2>Contact Us</h2>
        <div>
            <h2>Name       :Raviteja</h2>
            <h2>Roll No    :20071A05A5</h2>
            <h2>Mobile no. :8179709423</h2>
            <h2>e-mail     :rteja6935@gmail.com</h2>
            <h2>Location:Hyderabad</h2>
            <h2>Website :www.epirecipes.com</h2>
        </div>
    </div>
  ) ;
};

export default Contact;
