import React, { useState, useEffect } from 'react';
import '../App.css'
const RecipeFilter = () => {
  const [recipes, setRecipes] = useState([]);
  const [query, setQuery] = useState('');
  const [minCalories, setMinCalories] = useState('');
  const [maxCalories, setMaxCalories] = useState('');
  const [minRating, setMinRating] = useState('');
  const [maxRating, setMaxRating] = useState('');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);

  // Function to fetch recipes from Flask backend
  const fetchRecipes = async () => {
    let url = `http://localhost:5000/search?q=${query}&min_calories=${minCalories}&max_calories=${maxCalories}&min_rating=${minRating}&max_rating=${maxRating}&page=${page}&size=${size}`;

    try {
      const response = await fetch(url);
      const data = await response.json();
      setRecipes(data);
    } catch (error) {
      console.error("Error fetching recipes:", error);
    }
  };

  // Function to handle form submission
  const handleSearch = (e) => {
    e.preventDefault();
    fetchRecipes();
  };

  return (
    
    <div className='Nav-Bar'>
      <div>
      <h1>Recipe Search</h1>
      </div>
      <div>
      {/* Form for search filters */}
      <form onSubmit={handleSearch}>
        <input 
          type="text" 
          placeholder="Search Recipe" 
          value={query} 
          onChange={(e) => setQuery(e.target.value)} 
        />
        <input 
          type="number" 
          placeholder="Min Calories" 
          value={minCalories} 
          onChange={(e) => setMinCalories(e.target.value)} 
        />
        <input 
          type="number" 
          placeholder="Max Calories" 
          value={maxCalories} 
          onChange={(e) => setMaxCalories(e.target.value)} 
        />
        <input 
          type="number" 
          placeholder="Min Rating" 
          value={minRating} 
          onChange={(e) => setMinRating(e.target.value)} 
        />
        <input 
          type="number" 
          placeholder="Max Rating" 
          value={maxRating} 
          onChange={(e) => setMaxRating(e.target.value)} 
        />
        <button type="submit">Search</button>
      </form>
      </div>
      {/* Displaying results */}
      <div>
        <h2>Search Results</h2>
        {recipes.length > 0 ? (
          <ul>
            {recipes.map((recipe, index) => (
              <li key={index}>
                <h3>{recipe._source.title}</h3>
                <p>Calories: {recipe._source.calories}</p>
                <p>Rating: {recipe._source.rating}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No recipes found</p>
        )}
      </div>
    </div>
  );
};

export default RecipeFilter;
