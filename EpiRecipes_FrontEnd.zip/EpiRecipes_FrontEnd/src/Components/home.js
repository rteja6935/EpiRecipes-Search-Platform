import React from 'react';
import '../App.css';
import { useState, useEffect } from 'react';
const Home = () => {

    const [recipes1, set_Recipes] = useState([]);
    const [query1, set_Query] = useState('');
  // Function to fetch recipes from Flask backend
  const fetch_Recipes = async () => {
    let url = `http://localhost:5000/search?q=${query1}`;

    try {
      const response = await fetch(url);
      const data = await response.json();
      set_Recipes(data);
    } catch (error) {
      console.error("Error fetching recipes:", error);
    }
  };

  // Function to handle form submission
  const handle_Search = (e) => {
    e.preventDefault();
    fetch_Recipes();
  };
  return (
    <div>
    <div className="search-bar-container">
        <h2 className='recipe_name'>Find what you're craving.</h2>
      <form onSubmit={handle_Search}>
        <input 
          type="text" 
          className="search-bar" placeholder="Search for Recipes"
          value={query1} 
          onChange={(e) => set_Query(e.target.value)} 
        />
        <button  style={{
    backgroundColor: '#4CAF50', /* Green background */
    border: 'none', /* No border */
    color: 'white', /* White text */
    padding: '10px 20px', /* Padding around the button */
    fontSize: '16px', /* Font size */
    borderRadius: '5px', /* Rounded corners */
    cursor: 'pointer', /* Pointer on hover */
    transition: 'background-color 0.3s ease', /* Smooth transition */
    margin: '10px ' /* Spacing around the button */
  }}type="submit">Search</button>
      </form>
      </div>
      <div>
      {recipes1.length > 0 ? (
          <ul>
            {recipes1.map((recipe, index) => (
              <li key={index}>
                <h3>{recipe._source.title}</h3>
                <p>Calories: {recipe._source.calories}</p>
                <p>Rating: {recipe._source.rating}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No recipes found</p>
        )}
    </div>
    </div>
  );
};

export default Home;
