import React from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import Home from './Components/home.js';
import Recipes from './Components/RecipeFilter.js';
import About from './Components/About.js';
import Contact from './Components/Contact.js';
import '../src/App.css'; // Optional: for adding custom styles

function App() {
  return (
    <div>
      <div className="navbar">
        <div className="navbar-left">
          <h1>Epi Recipes</h1>
        </div>
        <div className="navbar-right">
          <ul className="nav-links">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/recipes">RecipeFilter</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
      </div>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recipes" element={<Recipes />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </div>
  );
}

export default App;
